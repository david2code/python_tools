#!/usr/bin/python3
#coding=utf-8
from optparse import OptionParser
import sys
import tty, termios
import os
import requests
import ata_parse
import json
import re

# 此脚本用于向ata查询数据
# 通过从文件中读取request_id和storage_time，然后构造 url 向ata进行查询
# 将查询结果进行解析，然后在终端展示

# curl "http://127.0.0.1:9903/query_raw?request_id=de9b778e-3f6b-459a-a531-887bc33f51a3&storage_time=1741338484"
ATA_URL = "http://127.0.0.1:9903/query_raw?"

USER_IDENTIFY_PATH = "/opt/ata/plugins/user-identify-bootstrap/"
# 已识别的或者确认
app_white_list_file_name = USER_IDENTIFY_PATH + "app_white_list.json"
request_id_db_file_name = USER_IDENTIFY_PATH + "request_id_db.json"
app_path_white_list_file_name = USER_IDENTIFY_PATH + "app_path_white_list.json"

def printRequest(result):
    print(f"-------------------------request start----------------------------------------------")
    print(f"{result['req_start_line']}")
    print(f"{result['req_headers']}")
    print(f"{result['req_body'][:1500]}")
    print(f"-------------------------request end----------------------------------------------")
    print(f"-------------------------response start----------------------------------------------")
    print(f"{result['resp_start_line']}")
    print(f"{result['resp_headers']}")
    print(f"{result['resp_body'][:1500]}")
    print(f"-------------------------response end----------------------------------------------")

def getPathFromReqStartLine(req_start_line):
    pattern = r"\s([^\s]*)\s"
    match = re.search(pattern, req_start_line)
    if match:
        path = match.group(1)
        return path
    else:
        return None

class AppWhiteList:
    def __init__(self):
        print("load %s" % app_white_list_file_name)
        self.list = {}
        self.changed = False
        if not os.path.exists(app_white_list_file_name):
            return
        with open(app_white_list_file_name, 'r') as file:
            self.list = json.load(file)
        #print(json.dumps(self.list))
        print("load size: %d" % len(self.list))

    def add(self, app_name, reason):
        self.changed = True
        self.list[app_name] = reason;

    def query(self, app_name):
        if app_name in self.list:
            return self.list[app_name]
        else:
            return None

    def dump(self):
        print("dump %s, size: %d" % (app_white_list_file_name, len(self.list)))
        if len(self.list) == 0:
            print("app white list empty")
            return
        if self.changed == False:
            print("no changed")
            return
        with open(app_white_list_file_name, 'w') as file:
            json.dump(self.list, file)
            #print("open success")

    def __del__(self):
        #self.dump()
        print("AppWhiteList del")

class AppPathWhiteList:
    def __init__(self):
        print("load %s" % app_path_white_list_file_name)
        self.map = {}
        self.changed = False
        if not os.path.exists(app_path_white_list_file_name):
            return
        with open(app_path_white_list_file_name, 'r') as file:
            self.map = json.load(file)
        print("load size: %d" % len(self.map))

    def add(self, app_address, path, request_id):
        if app_address in self.map:
            if path in self.map[app_address]:
                print("app_address: %s, path: %s exist" % (app_address, path));
                return
            else:
                self.map[app_address][path] = {"request_id" : request_id}
        else:
            self.map[app_address] = { path : {"request_id" : request_id} }
        self.changed = True
        #input()

    def dump(self):
        print("dump %s, size: %d" % (app_path_white_list_file_name, len(self.map)))
        if len(self.map) == 0:
            print("app path whitelist map empty")
            return
        if self.changed == False:
            print("no changed")
            return
        with open(app_path_white_list_file_name, 'w') as file:
            json.dump(self.map, file)
            #print("open success")

    def __del__(self):
        #self.dump()
        print("AppPathWhiteList del")

class RequestIdDb:
    def __init__(self):
        print("load %s" % request_id_db_file_name)
        self.map = {}
        self.changed = False
        if not os.path.exists(request_id_db_file_name):
            return
        with open(request_id_db_file_name, 'r') as file:
            self.map = json.load(file)
        print("load size: %d" % len(self.map))

    def add(self, request_id, content):
        self.changed = True
        self.map[request_id] = content;

    def query(self, request_id):
        if request_id in self.map:
            return self.map[request_id]
        else:
            return None

    def dump(self):
        print("dump %s, size: %d" % (request_id_db_file_name, len(self.map)))
        if len(self.map) == 0:
            print("request_id_db map empty")
            return
        if self.changed == False:
            print("no changed")
            return
        with open(request_id_db_file_name, 'w') as file:
            json.dump(self.map, file)
            #print("open success")

    def __del__(self):
        #self.dump()
        print("RequestIdDb del")


class Analyse:
    def __init__(self, file_name):
        self.app_whitelist_ = AppWhiteList()
        self.app_path_whitelist_ = AppPathWhiteList()
        self.request_id_db_ = RequestIdDb()
        self.file_name_ = file_name
        input()

    def getch(self):
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch


    def process(self):
        app_dict = dict()
        total_records = 0
        with open(self.file_name_, 'r') as file:
            for line in file:
                total_records += 1
                print(line)
                line = line.strip();
                lst = line.split(" ");
                print(lst);
                app_address = lst[0];
                downstream_ip = lst[1];
                value = { "request_id" : lst[2], "storage_time" : lst[3] }
                if app_address in app_dict:
                    if downstream_ip in app_dict[app_address]:
                        app_dict[app_address][downstream_ip].append(value);
                    else:
                        app_dict[app_address][downstream_ip] = [value]
                    #print(app_address)
                    #app_dict[app_address].append(value)
                else:
                    app_dict[app_address] = { downstream_ip : [value] }

        
        print("total records: ", total_records)
        input()
        app_size = len(app_dict)
        app_pos = 0
        quit = False
        quit_app = False
        quit_ip = False
        for app_address, ip_dict in app_dict.items():
            #print("app_address: ", app_address)
            app_pos += 1
            ip_size = len(ip_dict)
            ip_pos = 0
            #input()
            for downstream_ip, lst in ip_dict.items():
                #print("  downstream_ip: ", downstream_ip)
                ip_pos += 1

                lst_size = len(lst)
                lst_pos = 0

                for item in lst:
                    request_id = item["request_id"]
                    storage_time = item["storage_time"]
                    url = ATA_URL + "request_id=" + request_id + "&storage_time=" + storage_time
                    lst_pos += 1

                    os.system("clear")
                    print("app_address: %s, (%d / %d)" % (app_address, app_pos, app_size))
                    reason = self.app_whitelist_.query(app_address)
                    if reason:
                        print("app_address: %s in white list, reason: %s" % (app_address, reason["reason"]))
                    print("downstream_ip: %s, (%d / %d)" % (downstream_ip, ip_pos, ip_size))
                    print("request_id: %s, storage_time: %s, (%d / %d)" % (request_id, storage_time, lst_pos, lst_size))
                    print("url: ", url)

                    result = self.request_id_db_.query(request_id)
                    if result is None:
                        print("query json db failed!")

                        response = requests.get(url)
                        if response.status_code != 200:
                            print("query ata failed")
                        else:
                            #print(response.status_code)
                            #print(response.url)
                            #print(response.content)
                            result = {}
                            ata_parse.parseAtaResult(response.content, result)
                            self.request_id_db_.add(request_id, result)

                    if result:
                        print(f"-------------------------request start----------------------------------------------")
                        print(f"{result['req_start_line']}")
                        print(f"{result['req_headers']}")
                        print(f"{result['req_body'][:1500]}")
                        print(f"-------------------------request end----------------------------------------------")
                        print(f"-------------------------response start----------------------------------------------")
                        print(f"{result['resp_start_line']}")
                        print(f"{result['resp_headers']}")
                        print(f"{result['resp_body'][:1500]}")
                        print(f"-------------------------response end----------------------------------------------")

                    #print("\033[0;5H", end="")
                    #sys.stdout.write("\033[5;10H")
                    #sys.stdout.flush()

                    ch = self.getch()
                    #print(ch)
                    if ch == 'j':
                        print("next")
                    elif ch == 'k':
                        quit_ip = True
                    elif ch == 'l':
                        quit_ip = True
                        quit_app = True
                    elif ch == 'a': # 已识别，并加入白名单
                        #self.app_whitelist_.add(app_address, "identified")
                        self.app_whitelist_.add(app_address, {"reason": "identified", "request_id" : request_id})
                        quit_ip = True
                        quit_app = True
                    elif ch == 'd': # 未识别，已确定应用没有登陆接口，将应用加入白名单
                        self.app_whitelist_.add(app_address, {"reason": "no login path", "request_id" : request_id})
                        quit_ip = True
                        quit_app = True
                    elif ch == 's': # 未识别，将path加入白名单
                        if result:
                            req_start_line = result['req_start_line']
                            pattern = r"\s([^\s]*)\s"
                            match = re.search(pattern, req_start_line)
                            if match:
                                path = match.group(1)
                                #print("path: ", path)

                                self.app_path_whitelist_.add(app_address, path, request_id)
                            else:
                                print("req_start_line: %s parse path error", req_start_line)
                                input()

                    elif ch == 'q':
                        quit = True
                        quit_ip = True
                        quit_app = True

                    if quit_ip:
                        quit_ip = False
                        break
                if quit_app:
                    quit_app = False
                    break

            if quit:
                quit = False
                break
        self.app_whitelist_.dump()
        self.app_path_whitelist_.dump()
        self.request_id_db_.dump()

    def __del__(self):
        print("leave")

class Output:
    def __init__(self):
        self.app_whitelist_ = AppWhiteList()
        self.request_id_db_ = RequestIdDb()
        input()
    def print(self):
        app_map = self.app_whitelist_.list
        print("output", len(app_map))
        for app_address, reason_map in app_map.items():
            if reason_map["reason"] == "identified":
                request_id = reason_map["request_id"]
                print(f"应用地址： {app_address}")
                print(f"对应应用： ")

class PathItem:
    def __init__(self, path):
        print(path)
        self.orig_path_ = path
        pos = path.find('?')
        print(pos)
        self.param_keys_ = []
        if pos == -1:
            self.path_ = path
            self.param_ = ""
        else:
            self.path_ = path[0:pos]
            param = path[pos + 1:]
            print(param)
            if param:
                self.param_keys_ = param.split("&")
                print(self.param_keys_)
                for i in range(len(self.param_keys_)):
                    item = self.param_keys_[i]
                    print(item)
                    kv = item.split("=")
                    print(kv[0])
                    self.param_keys_[i] = kv[0]
                print(self.param_keys_)

        print(self.path_)
        self.path_segments_ = self.path_.split("/")
        print(self.path_segments_)
        #self.merge_start_ = -1
        #self.merge_end_ = -1
        self.diff_pos_ = -1
        self.seg_lst_ = set()
        self.seg_merge_set_ = set()
        self.others_ = []

    #def merge1(self, other):
    #    if len(self.path_) != len(other.path_):
    #        return False
    #    else:
    #        if self.param_keys_ != other.param_keys_:
    #            return False
    #        else:
    #            start = -1
    #            end = -1
    #            for i in range(len(self.path_)):
    #                if self.path_[i] != other.path_[i]:
    #                    if self.path_[i].isdigit() and other.path_[i].isdigit():
    #                        if start == -1:
    #                            start = i
    #                        else:
    #                            if end != -1:
    #                                print("merge failed: two unmatch")
    #                                return False
    #                    else:
    #                        print("merge failed: not digit")
    #                        return False
    #                else:
    #                    if end == -1 and start != -1:
    #                        end = i;

    #            if end == -1 and start != -1:
    #                end = len(self.path_);

    #            if end != -1 and start != -1:
    #                print(start)
    #                print(end)
    #                print(self.path_[start : end])
    #                if self.merge_start_ == -1:
    #                    self.merge_start_ = start
    #                    self.merge_end_ = end
    #                else:
    #                    if start <= self.merge_start_ and end >= self.merge_end_:
    #                        self.merge_start_ = start
    #                        self.merge_end_ = end
    #                    else:
    #                        print("merge failed: confilict to exist! exist: %s, new: %s" % (self.path_[self.merge_start_:self.merge_end_], self.path_[start, end]))
    #                        return False

    #                return True
    #            else:
    #                print("merge failed: all equal")
    #                return False

    def split_segment(self, seg):
        segs = []
        if len(seg) == 0:
            return segs
        start = -1
        before_is_digit = False
        print(seg)
        for i in range(len(seg)):
            if i == 0:
                start = i
                if seg[i].isdigit():
                    before_is_digit = True
                else:
                    before_is_digit = False
            else:
                now_is_digit = False
                if seg[i].isdigit():
                    now_is_digit = True

                if now_is_digit != before_is_digit:
                    v = seg[start:i]
                    segs.append({"v" : v, "is_digit" : before_is_digit})
                    start = i
                    before_is_digit = now_is_digit
        if start != len(seg):
            v = seg[start:]
            print(v)
            segs.append({"v" : v, "is_digit" : before_is_digit})

        print(segs)
        return segs

    def merge(self, other):
        print("merge exist: %s, other: %s" % (self.orig_path_, other.orig_path_))
        if len(self.path_segments_) != len(other.path_segments_):
            return False
        else:
            if self.param_keys_ != other.param_keys_:
                return False
            else:
                start = -1
                end = -1
                diff_pos = -1
                for i in range(len(self.path_segments_)):
                    if self.path_segments_[i] != other.path_segments_[i]:
                        if diff_pos == -1:
                            diff_pos = i;
                        else:
                            print("merge failed: two unmatch")
                            return False

                if diff_pos == -1:
                    print("merge failed: all equal")
                else:
                    print("diff_pos: %d" % diff_pos)
                    seg1_lst = []
                    if self.diff_pos_ != -1:
                        if diff_pos != self.diff_pos_:
                            print("merge failed: confilict to exist! exist: %s, new: %s" % (self.diff_pos_, diff_pos))
                            return False
                        seg1_lst = self.seg_lst_;
                    else:
                        seg1_lst = self.split_segment(self.path_segments_[diff_pos])
                    seg2_lst = self.split_segment(other.path_segments_[diff_pos])
                    merge_set = set()
                    if len(seg1_lst) == 0 or len(seg1_lst) != len(seg2_lst):
                        return False
                    for i in range(len(seg1_lst)):
                        if seg1_lst[i]["is_digit"] != seg2_lst[i]["is_digit"]:
                            print("merge failed: left: %s, right: %s" % (seg1_lst[i]["is_digit"], seg2_lst[i]["is_digit"]))
                            return False
                        else:
                            if seg1_lst[i]["v"] != seg2_lst[i]["v"]:
                                if not seg1_lst[i]["is_digit"]:
                                    print("merge failed: left: %s, right: %s" % (seg1_lst[i]["is_digit"], seg2_lst[i]["is_digit"]))
                                    return False
                                else:
                                    merge_set.add(i)
                    if len(merge_set) == 0:
                        print("merge failed: not find digit undifference")
                        return False

                    if self.diff_pos_ != -1:
                        intersection = self.seg_merge_set_ & merge_set;
                        if len(intersection) == 0:
                            print("merge failed: confilict with exist")
                            return False
                        self.seg_merge_set_ = intersection

                    else:
                        self.diff_pos_ = diff_pos
                        self.seg_lst_ = seg1_lst;
                        self.seg_merge_set_ = merge_set;

                    #print(merge_set)

                self.others_.append(other);
                return True

    def show(self):
        if len(self.others_) == 0:
            print(self.orig_path_)
            return

        print(self.orig_path_)
        for item in self.others_:
            item.show()

        seg_value = ""
        for i in range(len(self.seg_lst_)):
            if i in self.seg_merge_set_:
                #print(i)
                #print(self.seg_lst_[i])
                seg_value += "\d+"
            else:
                seg_value += self.seg_lst_[i]["v"]
        #print(seg_value)
        re_path = ""
        for i in range(len(self.path_segments_)):
            if i == self.diff_pos_:
                re_path += seg_value
            else:
                re_path += self.path_segments_[i]

            if i != len(self.path_segments_) - 1:
                re_path += "\/"
        if len(self.param_keys_):
            re_path += "\?"
            for i in range(len(self.param_keys_)):
                re_path += self.param_keys_[i] + "=[^&=\s]+"
                if i != len(self.param_keys_) - 1:
                    re_path += "&"
        print("   ", re_path)



class PathMerge:
    def __init__(self):
        self.app_path_whitelist_ = AppPathWhiteList()
        #self.request_id_db_ = RequestIdDb()
        #input()
    def print(self):
        app_map = self.app_path_whitelist_.map
        print("output", len(app_map))

        for app_address, path_map in app_map.items():
            print(f"应用地址： {app_address}")
            path_group = []
            skip = False
            for path, _ in path_map.items():
                print(f"path： {path}")
                if path == "/download":
                    skip = True
                    break

                s = PathItem(path)
                if len(path_group) == 0:
                    path_group.append(s)
                else:
                    merged = False
                    for i in range(len(path_group)):
                        if path_group[i].merge(s):
                            print("merge success")
                            merged = True
                            break
                    if not merged:
                        path_group.append(s)
                print("---------------")
                #input()
            print("---------------result ----")
            #input()

            for i in range(len(path_group)):
                print(i)
                path_group[i].show()

            if not skip:
                input()
 
if __name__ == '__main__':
    parse = OptionParser()
    parse.add_option("-f", "--file", dest="filename", help="path to record file", metavar="FILE")
    parse.add_option("-o", "--output", action="store_true", dest="output", help="print whitelist to file")
    parse.add_option("-m", "--merge", action="store_true", dest="merge", help="merge path")
    (options, args) = parse.parse_args()
    #print(options)
    #print(args)
    print(options.output)

    #path =  "/2s211b/b/c/d?tk=9fb03002759aea473abbf0b78bd942a75dbd20229ed7b8ceaef727338b4c0f2b323f6e7f03b881db21133b1bf2ae5bc5&iv=679f3efd86a986bd&encrypt=17"
    #path2 = "/1s233b/b/c/d?tk=9fb03002759aea473abbf0b78bd942a75dbd20229ed7b8ceaef727338b4c0f2b323f6e7f03b881db21133b1bf2ae5bc5&iv=310a0254b8490e4c&encrypt=17"
    #path3 = "/123s2b/b/c/d?tk=9fb03002759aea473abbf0b78bd942a75dbd20229ed7b8ceaef727338b4c0f2b323f6e7f03b881db21133b1bf2ae5bc5&iv=310a0254b8490e4c&encrypt=17"
    #s = PathItem(path)
    #s2 = PathItem(path2)
    #s.split_segment("123cc_sbd_123.html")
    #s.split_segment("12322")
    #s.split_segment("abd")
    #s.split_segment("")
    #quit()
    #if s.merge(s2):
    #    print("match")
    #else:
    #    print("not match")

    #s3 = PathItem(path3)
    #if s.merge(s3):
    #    print("match")
    #else:
    #    print("not match")

    #print("-------------------------------")
    #s.show()
    #quit()

    if options.output is True:
        o = Output()
        o.print()
        quit()
    if options.merge is True:
        print("merge path")
        o = PathMerge()
        o.print()
        quit()

    if options.filename is None:
        parse.print_help()
        quit()
    else:
        file_name = USER_IDENTIFY_PATH + options.filename

    if not os.path.exists(file_name):
        print("record file: %s not exists" % file_name);
        quit()

    ana = Analyse(file_name)
    ana.process()

