#!/bin/python3
from query_pb2 import QueryResult
import chardet

def decodeBody(body):
    if len(body) >= 1 and len(body[0]) != 0:
        det = chardet.detect(body[0])
        s_data = body[0]
        encoding = det['encoding']
        print(encoding)
        if encoding:
            try:
                s_data = s_data.decode(det['encoding'], errors='replace')
            except:
                print("decode error")
        else:
            print("unknown encoding")
        return repr(s_data)
    else:
        return ""

def parseAtaResult(serialized_data, result):
    #print(serialized_data)
    data = QueryResult()
    data.ParseFromString(serialized_data)
    #print(f"    request_id: {result.access_log.request_id}")
    result["req_start_line"] = data.access_log.request.raw_start_line
    result["req_headers"] = data.access_log.request.raw_headers
    result["req_body"] = decodeBody(data.access_log.request.raw_body)
    result["resp_start_line"] = data.access_log.response.raw_start_line
    result["resp_headers"] = data.access_log.response.raw_headers
    result["resp_body"] = decodeBody(data.access_log.response.raw_body)

